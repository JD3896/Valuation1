// /api/quote.js
// Vercel serverless function — runs on Vercel's servers, NOT in the browser.
// The Finnhub API key stays here as an environment variable and is never
// exposed to the client. The frontend calls this endpoint instead of
// calling Finnhub directly.
//
// Setup:
//   1. Sign up at https://finnhub.io (free tier: 60 calls/min)
//   2. Copy your API key
//   3. In Vercel: Project Settings -> Environment Variables
//      add FINNHUB_API_KEY = <your key>
//   4. Redeploy

export default async function handler(req, res) {
  const { symbol } = req.query;

  if (!symbol) {
    return res.status(400).json({ error: 'Missing ?symbol= parameter' });
  }

  const apiKey = process.env.FINNHUB_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server missing FINNHUB_API_KEY env var' });
  }

  try {
    const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol.toUpperCase())}&token=${apiKey}`;
    const r = await fetch(url);

    if (!r.ok) {
      return res.status(r.status).json({ error: `Finnhub returned ${r.status}` });
    }

    const data = await r.json();

    // Finnhub returns c:0 for an invalid/unknown symbol rather than an error
    if (data.c === 0 && data.pc === 0) {
      return res.status(404).json({ error: `No data for symbol "${symbol}"` });
    }

    // Cache briefly at the edge so rapid repeat requests (e.g. tab refocus)
    // don't burn through your rate limit.
    res.setHeader('Cache-Control', 's-maxage=15, stale-while-revalidate=30');

    return res.status(200).json({
      symbol: symbol.toUpperCase(),
      price: data.c,        // current price
      high: data.h,         // day high
      low: data.l,          // day low
      prevClose: data.pc,   // previous close
      change: data.c - data.pc,
      changePct: data.pc ? ((data.c - data.pc) / data.pc) * 100 : null,
      timestamp: data.t,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Fetch to Finnhub failed', detail: err.message });
  }
}
