// /api/check-subscription.js
// Stub for gating access behind an active subscription.
// Wire this up once you've added Clerk (auth) and Supabase (subscription table).
//
// Flow:
//   1. Clerk gives you the logged-in user's ID on the frontend.
//   2. Frontend calls this endpoint with that user ID.
//   3. This function looks up the user's subscription status in Supabase
//      (a table you update via a Stripe webhook whenever a subscription
//      is created / renewed / cancelled).
//   4. Frontend shows the DCF tool only if { active: true } comes back.
//
// This keeps the "is this a paying customer" check server-side, so it
// can't be bypassed by editing client-side JS.

export default async function handler(req, res) {
  const { userId } = req.query;

  if (!userId) {
    return res.status(400).json({ error: 'Missing ?userId= parameter' });
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;

  if (!supabaseUrl || !supabaseKey) {
    // Not wired up yet — fail closed (no access) rather than open.
    return res.status(200).json({ active: false, note: 'Subscription check not configured yet' });
  }

  try {
    const r = await fetch(
      `${supabaseUrl}/rest/v1/subscriptions?user_id=eq.${encodeURIComponent(userId)}&select=status`,
      { headers: { apikey: supabaseKey, Authorization: `Bearer ${supabaseKey}` } }
    );
    const rows = await r.json();
    const active = Array.isArray(rows) && rows.some(row => row.status === 'active');
    return res.status(200).json({ active });
  } catch (err) {
    return res.status(500).json({ active: false, error: err.message });
  }
}
